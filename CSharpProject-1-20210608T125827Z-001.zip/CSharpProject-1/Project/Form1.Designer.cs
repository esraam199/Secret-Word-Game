﻿
namespace Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Easy = new System.Windows.Forms.Button();
            this.Meduim = new System.Windows.Forms.Button();
            this.Hard = new System.Windows.Forms.Button();
            this.Categrory1 = new System.Windows.Forms.Button();
            this.Categrory2 = new System.Windows.Forms.Button();
            this.Categrory3 = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Easy
            // 
            this.Easy.BackColor = System.Drawing.Color.Transparent;
            this.Easy.FlatAppearance.BorderSize = 0;
            this.Easy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Easy.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Easy.Location = new System.Drawing.Point(208, 21);
            this.Easy.Name = "Easy";
            this.Easy.Size = new System.Drawing.Size(95, 37);
            this.Easy.TabIndex = 0;
            this.Easy.Text = "Easy";
            this.Easy.UseVisualStyleBackColor = false;
            this.Easy.Click += new System.EventHandler(this.Easy_Click);
            // 
            // Meduim
            // 
            this.Meduim.BackColor = System.Drawing.Color.Transparent;
            this.Meduim.FlatAppearance.BorderSize = 0;
            this.Meduim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Meduim.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Meduim.Location = new System.Drawing.Point(148, 48);
            this.Meduim.Name = "Meduim";
            this.Meduim.Size = new System.Drawing.Size(109, 37);
            this.Meduim.TabIndex = 1;
            this.Meduim.Text = "Meduim";
            this.Meduim.UseVisualStyleBackColor = false;
            this.Meduim.Click += new System.EventHandler(this.Meduim_Click);
            // 
            // Hard
            // 
            this.Hard.BackColor = System.Drawing.Color.Transparent;
            this.Hard.FlatAppearance.BorderSize = 0;
            this.Hard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Hard.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hard.Location = new System.Drawing.Point(271, 48);
            this.Hard.Name = "Hard";
            this.Hard.Size = new System.Drawing.Size(95, 37);
            this.Hard.TabIndex = 2;
            this.Hard.Text = "Hard";
            this.Hard.UseVisualStyleBackColor = false;
            this.Hard.Click += new System.EventHandler(this.Hard_Click);
            // 
            // Categrory1
            // 
            this.Categrory1.BackColor = System.Drawing.Color.Transparent;
            this.Categrory1.FlatAppearance.BorderSize = 0;
            this.Categrory1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Categrory1.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categrory1.Location = new System.Drawing.Point(121, 101);
            this.Categrory1.Name = "Categrory1";
            this.Categrory1.Size = new System.Drawing.Size(136, 37);
            this.Categrory1.TabIndex = 3;
            this.Categrory1.Text = "Football Player";
            this.Categrory1.UseVisualStyleBackColor = false;
            this.Categrory1.Click += new System.EventHandler(this.Categrory1_Click);
            // 
            // Categrory2
            // 
            this.Categrory2.BackColor = System.Drawing.Color.Transparent;
            this.Categrory2.FlatAppearance.BorderSize = 0;
            this.Categrory2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Categrory2.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categrory2.Location = new System.Drawing.Point(121, 144);
            this.Categrory2.Name = "Categrory2";
            this.Categrory2.Size = new System.Drawing.Size(136, 36);
            this.Categrory2.TabIndex = 4;
            this.Categrory2.Text = "Actors";
            this.Categrory2.UseVisualStyleBackColor = false;
            this.Categrory2.Click += new System.EventHandler(this.Categrory2_Click);
            // 
            // Categrory3
            // 
            this.Categrory3.BackColor = System.Drawing.Color.Transparent;
            this.Categrory3.FlatAppearance.BorderSize = 0;
            this.Categrory3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Categrory3.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categrory3.Location = new System.Drawing.Point(121, 186);
            this.Categrory3.Name = "Categrory3";
            this.Categrory3.Size = new System.Drawing.Size(136, 47);
            this.Categrory3.TabIndex = 5;
            this.Categrory3.Text = "Films";
            this.Categrory3.UseVisualStyleBackColor = false;
            this.Categrory3.Click += new System.EventHandler(this.Categrory3_Click);
            // 
            // Back
            // 
            this.Back.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.BackgroundImage = global::Project.Properties.Resources.back;
            this.Back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Back.FlatAppearance.BorderSize = 0;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.Location = new System.Drawing.Point(9, 288);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(71, 42);
            this.Back.TabIndex = 6;
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Next
            // 
            this.Next.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Next.BackColor = System.Drawing.Color.Transparent;
            this.Next.BackgroundImage = global::Project.Properties.Resources.Play_Button;
            this.Next.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Next.FlatAppearance.BorderSize = 0;
            this.Next.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Next.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Next.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Next.Location = new System.Drawing.Point(290, 272);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(76, 58);
            this.Next.TabIndex = 7;
            this.Next.UseVisualStyleBackColor = false;
            this.Next.UseWaitCursor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(242, 139);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 47);
            this.button1.TabIndex = 8;
            this.button1.Text = "Countrys";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(242, 96);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 47);
            this.button2.TabIndex = 9;
            this.button2.Text = "Potitions";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BackgroundImage = global::Project.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(378, 339);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Categrory3);
            this.Controls.Add(this.Categrory2);
            this.Controls.Add(this.Categrory1);
            this.Controls.Add(this.Hard);
            this.Controls.Add(this.Meduim);
            this.Controls.Add(this.Easy);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Easy;
        private System.Windows.Forms.Button Meduim;
        private System.Windows.Forms.Button Hard;
        private System.Windows.Forms.Button Categrory1;
        private System.Windows.Forms.Button Categrory2;
        private System.Windows.Forms.Button Categrory3;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

